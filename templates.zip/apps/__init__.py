"""
Applications package.
"""
