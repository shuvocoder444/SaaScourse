"""
Tenants application.
"""
